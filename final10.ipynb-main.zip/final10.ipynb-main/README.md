# trash-detection-YoloV5
## Step 1
so you just need to download Taco dataset then change annotation in .txt file with tool https://roboflow.com/
you may directly use my roboflow_file too from roboflow https://app.roboflow.com/aeliya-sakeen
## Step 2
you may use jupyter notebook pycharm or any IDE, for people who dont have GPU on their laptops may use Google Collab then train your dataset 100epoch a day
clone git repository of yolov5.
just use the code for training with your files modifications.
if you are going to put weights on raspberry pi then use yolov5s or yolov5m. you may get more info from https://learnopencv.com/custom-object-detection-training-using-yolov5/#:~:text=YOLOv5s%3A%20It%20is%20the%20small,model%20with%2021.2%20million%20parameters.
